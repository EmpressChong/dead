#!/usr/bin/sh
node server/index
