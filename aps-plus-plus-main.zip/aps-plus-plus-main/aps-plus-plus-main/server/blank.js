// Yes, this is intended to do absolutely nothing but to keep the terminal open.
// Don't remove it though. REPL_WINDOW depends on this.
setInterval(a=>a,2**31-1);